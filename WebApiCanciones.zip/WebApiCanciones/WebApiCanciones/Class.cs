﻿namespace WebApiCanciones
{
    public class Class
    {
    }
}
